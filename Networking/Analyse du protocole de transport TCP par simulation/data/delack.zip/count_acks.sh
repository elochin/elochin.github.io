r=$(cat tcp_delack.tr | grep ^r | grep " 1 2 tcp " | wc -l)
s=$(cat tcp_delack.tr | grep ^+ | grep " 2 1 ack " | wc -l)
echo "Packets received:" $r
echo "Acks sent:" $s
echo "Ratio s/r:" $((100*$s/$r))"%"
