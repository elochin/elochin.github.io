#~/ns-2/ns-allinone-2.35/ns-2.35/ns tcp.tcl

err_rate=0
#err_rate=0.01
delack_interval='40ms'

echo "Without DelAck"
ns tcp_delack.tcl 0 $err_rate $delack_interval
cat cwnd.tr | awk '{print $2, $5}' | sed s/t// | sed s/v// > cwnd.txt
bash count_acks.sh

echo ""
echo "With DelAck"
ns tcp_delack.tcl 1 $err_rate $delack_interval
cat cwnd.tr | awk '{print $2, $5}' | sed s/t// | sed s/v// > cwnd_delack.txt
bash count_acks.sh
gnuplot cwnd.gp
