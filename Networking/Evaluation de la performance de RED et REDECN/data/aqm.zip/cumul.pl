$infile=$ARGV[0];

#we compute how many bytes were transmitted during time interval specified by granularity in ms
$sum=0;
$clock=0;
$count=1;
$cumul=0;

open (DATA, "<$infile")
	|| die "Can't open $infile: $!";
	
	while (<DATA>) {
		@x = split(' ');	
			$sum=$sum+$x[2];
	        	$count ++;	
			$cumul = $sum / $count;
			print STDOUT "$x[1] $x[2] $cumul\n";
	}
close DATA;
exit (0);
		
